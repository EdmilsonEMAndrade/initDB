import student from './student';
import studentGrade from './studentGrade';
import teacher from './teacher';

export default [student, studentGrade, teacher];
