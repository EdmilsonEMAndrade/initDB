export default class Formatter {
  static teste(value) {
    return `${value}-vini`;
  }
}
